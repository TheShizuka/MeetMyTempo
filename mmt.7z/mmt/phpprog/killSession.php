<?php 
session_start();
$_SESSION['pseudo'] = "0";

?>