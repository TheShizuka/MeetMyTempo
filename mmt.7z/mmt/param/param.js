const host ="http://localhost//mmt//phpprog/"

//adresse des prog

var backEnd = {

    'listeUtilisateur':         host+'listeUtilisateur.php',
    'creatUtilisateur':         host+'creatUtilisateur.php',
    'getUtilisateur':           host+'getUtilisateur.php',
    'creatConnexion':           host+'creatConnexion.php',
    'main':                     host+'Main.php',
    'updatePremium':                     host+'updatePremium.php',
    'killSession':                     host+'killSession.php',
    'session':                     host+'session.php',

}